# StaffSync

StaffSync is a responsive HR management interface for employee records,
attendance, leave requests, and profile management.

## Current build stage

- React + Vite frontend with Clerk sign-in and registration.
- Express API remains in `artifacts/api-server`.
- The StaffSync MongoDB readiness endpoint is `/api/staffsync/status`.
- Employee, attendance, and leave screens use clearly labeled preview data
  until MongoDB is connected. Preview changes are not persisted.
- No PostgreSQL schema or PostgreSQL-backed StaffSync data is used.

## MongoDB configuration

When the MongoDB connection is ready, add `MONGODB_URI` through Replit Secrets.
`MONGODB_DB` can optionally select a database name; otherwise the database in
the URI is used. Never place connection strings in source files.

Planned collections:

- `employees` — employee details linked to a Clerk user ID.
- `attendance` — check-in/check-out records by employee and date.
- `leaveRequests` — leave details, status, and review metadata.

MongoDB document types are kept in the API server's `src/lib` folder. The
connection is lazy so the API server can run in preview mode before MongoDB is
available.
