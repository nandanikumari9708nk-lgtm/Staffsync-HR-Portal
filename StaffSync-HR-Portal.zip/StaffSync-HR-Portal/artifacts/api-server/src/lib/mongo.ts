import { MongoClient, type Db } from "mongodb";

let client: MongoClient | undefined;
let databasePromise: Promise<Db> | undefined;

export function isMongoConfigured(): boolean {
  return Boolean(process.env.MONGODB_URI?.trim());
}

export async function getMongoDatabase(): Promise<Db | null> {
  const uri = process.env.MONGODB_URI?.trim();
  if (!uri) return null;

  if (!databasePromise) {
    client = new MongoClient(uri, { serverSelectionTimeoutMS: 3000 });
    databasePromise = client
      .connect()
      .then((connectedClient) =>
        connectedClient.db(process.env.MONGODB_DB?.trim() || undefined),
      )
      .catch(async (error: unknown) => {
        const failedClient = client;
        client = undefined;
        databasePromise = undefined;
        await failedClient?.close().catch(() => undefined);
        throw error;
      });
  }

  return databasePromise;
}
