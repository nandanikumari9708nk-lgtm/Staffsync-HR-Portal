import type { ObjectId } from "mongodb";

export type EmployeeStatus = "active" | "on-leave" | "inactive";
export type LeaveStatus = "pending" | "approved" | "rejected";
export type LeaveType = "annual" | "sick" | "personal" | "unpaid";
export type AttendanceStatus = "present" | "late" | "absent";

export interface EmployeeDocument {
  _id: ObjectId;
  clerkUserId: string;
  name: string;
  email: string;
  jobTitle: string;
  department: string;
  status: EmployeeStatus;
  location: string;
  startDate: Date;
  createdAt: Date;
  updatedAt: Date;
}

export interface AttendanceDocument {
  _id: ObjectId;
  employeeId: ObjectId;
  date: string;
  checkIn: Date | null;
  checkOut: Date | null;
  status: AttendanceStatus;
  createdAt: Date;
  updatedAt: Date;
}

export interface LeaveRequestDocument {
  _id: ObjectId;
  employeeId: ObjectId;
  type: LeaveType;
  startDate: Date;
  endDate: Date;
  days: number;
  reason: string;
  status: LeaveStatus;
  reviewedBy: string | null;
  reviewedAt: Date | null;
  createdAt: Date;
  updatedAt: Date;
}
