import { Router, type IRouter } from "express";
import { GetStaffSyncStatusResponse } from "@workspace/api-zod";
import { getMongoDatabase, isMongoConfigured } from "../lib/mongo";

const router: IRouter = Router();

router.get("/staffsync/status", async (req, res): Promise<void> => {
  const configured = isMongoConfigured();

  if (!configured) {
    res.json(
      GetStaffSyncStatusResponse.parse({
        configured: false,
        connected: false,
        mode: "preview",
        message: "MongoDB is not connected yet. StaffSync is in preview mode.",
      }),
    );
    return;
  }

  try {
    const database = await getMongoDatabase();
    if (!database) {
      res.json(
        GetStaffSyncStatusResponse.parse({
          configured: false,
          connected: false,
          mode: "preview",
          message: "MongoDB is not connected yet. StaffSync is in preview mode.",
        }),
      );
      return;
    }

    await database.command({ ping: 1 });
    res.json(
      GetStaffSyncStatusResponse.parse({
        configured: true,
        connected: true,
        mode: "connected",
        message: "MongoDB is connected.",
      }),
    );
  } catch (error) {
    req.log.warn({ err: error }, "MongoDB readiness check failed");
    res.json(
      GetStaffSyncStatusResponse.parse({
        configured: true,
        connected: false,
        mode: "unavailable",
        message: "MongoDB is configured but is not reachable right now.",
      }),
    );
  }
});

export default router;
