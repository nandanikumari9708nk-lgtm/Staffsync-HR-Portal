import { Router, type IRouter } from "express";
import healthRouter from "./health";
import staffSyncRouter from "./staffsync";

const router: IRouter = Router();

router.use(healthRouter);
router.use(staffSyncRouter);

export default router;
