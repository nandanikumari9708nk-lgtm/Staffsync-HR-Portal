---
name: StaffSync database choice
description: StaffSync must use MongoDB, and preview-only data must not be presented as persisted.
---

StaffSync must use MongoDB. Do not switch StaffSync to PostgreSQL. Until MongoDB is connected, employee, attendance, and leave data shown in the UI is preview-only and must be clearly labeled as not persisted.

**Why:** the user explicitly said not to switch databases and asked to build the UI and project structure while MongoDB is being connected.

**How to apply:** Keep StaffSync persistence and future API work on MongoDB. Only enable real saves after the MongoDB connection is configured; do not use the existing PostgreSQL package for StaffSync data.
